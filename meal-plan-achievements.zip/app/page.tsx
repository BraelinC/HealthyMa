"use client"

import Component from "../achievements-page"

export default function Page() {
  return <Component />
}
